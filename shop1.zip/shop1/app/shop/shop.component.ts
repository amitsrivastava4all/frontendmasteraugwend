import { Component, OnInit, ViewChild, ViewChildren, QueryList, AfterContentChecked } from '@angular/core';
import { itemOperations } from '../models/ItemOperations';
import { Item } from '../models/Item';
import {SearchComponent} from './search/search.component';
@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit,AfterContentChecked {
  ngAfterContentChecked(): void {
    console.log(this.searchList.length);
    this.searchList.forEach(ele=>{
      console.log(ele.giveMeData());
    })
    //throw new Error("Method not implemented.");
  }
  //@ViewChild(SearchComponent,{static:false})
  //searchComp:SearchComponent;
  @ViewChildren(SearchComponent)
  searchList:QueryList<SearchComponent> = new QueryList<SearchComponent>();
  items:Item [] = [];
  constructor() { }

  
  ngOnInit() {
    this.items = itemOperations.fillItems();
   
   // console.log(this.searchComp.giveMeData());
  }

  recPrice(price){
    this.items = itemOperations.search(price);
  }
  recSorted(sortedArray){
    this.items = sortedArray;
  }

}
