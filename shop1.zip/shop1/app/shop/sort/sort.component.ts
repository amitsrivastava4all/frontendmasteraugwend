import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { itemOperations } from 'src/app/models/ItemOperations';
import { Item } from 'src/app/models/Item';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.css']
})
export class SortComponent implements OnInit {

  @Output()
  recsorted:EventEmitter<Item[]>  = new EventEmitter<Item[]>();
  constructor() { }

  ngOnInit() {
  }
  doSort(event){
    var sortBy = event.target.value;
    if(sortBy!='-1'){
      this.recsorted.emit(itemOperations.sort(sortBy));
    }
  }

}
