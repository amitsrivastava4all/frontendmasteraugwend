export class Item{
    public isAdded:boolean ;
    constructor(public id:number, public name:string, public price:number, public url:string){
       this.isAdded = false;
    }
    toggle(){
        this.isAdded = !this.isAdded;
    }
}