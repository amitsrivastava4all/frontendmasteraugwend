import { Item } from './Item';


export const itemOperations = {
    items:[],
    search(price){
        return this.items.filter(itemObject=>itemObject.price>=price);
    },
    fillItems(){
        for(let i = 1; i<=5; i++){
            let img = i%2==0?'http://aux2.iconspalace.com/uploads/4941653891295546404.png':'http://aux4.iconspalace.com/uploads/846839393214911502.png';
            this.items.push(new Item(i, "Apple"+i,1000*i,img));
        }
        return this.items;
    }
}