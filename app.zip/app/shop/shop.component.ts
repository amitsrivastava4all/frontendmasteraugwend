import { Component, OnInit } from '@angular/core';
import { itemOperations } from '../models/ItemOperations';
import { Item } from '../models/Item';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {
  items:Item [] = [];
  constructor() { }

  ngOnInit() {
    this.items = itemOperations.fillItems();
  }
  recPrice(price){
    this.items = itemOperations.search(price);
  }

}
