import { Component, Input, EventEmitter, Output } from '@angular/core';

@Component({
    selector:'app-child1',
    templateUrl:'./child1.component.html',
    styleUrls:['./child1.component.css']
})
export class Child1Component{
    @Input()
    sendbyparent:string;
    @Output()
    callbychild:EventEmitter<string> = new EventEmitter<string>();
msg:string;
title:string;
takeInput(evt){
    this.title = evt.target.value;
    this.callbychild.emit(this.title);
}
call(){
    this.callbychild.emit(this.title);
}
constructor(){
    this.msg = 'Hello I am Child1';
}
}