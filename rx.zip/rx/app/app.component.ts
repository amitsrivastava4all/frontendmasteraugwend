import { Component } from '@angular/core';
import {SharedService} from './shared.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'servicerx';
  constructor(private sharedService:SharedService){

  }
  sendIt(data){
    var counter = 1;
    var t = setInterval(()=>{
      this.sharedService.getSubject().next(data+counter);
      counter++;
    },1000);
    setTimeout(()=>{
      this.sharedService.getSubject().complete();
      clearInterval(t)

    },10000);
   
      //this.sharedService.setMessage(data);
  }
}
