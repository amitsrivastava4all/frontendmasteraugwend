import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class SharedService{
    private subject:Subject<string> = new Subject<string>();
    msg:string;
    constructor(){
        this.msg = '';
    }
    getSubject():Subject<string>{
        return this.subject;
    }
    setMessage(msg):void{
        this.msg = msg;
    }
    getMessage():string{
        return this.msg;
    }
}